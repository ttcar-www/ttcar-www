# ttcar_www

Composer install

npm install

symfony server:start -d

Webpack :

npm run dev
npm run watch
 npm run build
